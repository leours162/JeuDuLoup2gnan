package com.example.jeuduloup2;

public class Marguerite extends Vegetaux {
    public Marguerite(int x, int y) {
        super(4, x, y);
    }
}

