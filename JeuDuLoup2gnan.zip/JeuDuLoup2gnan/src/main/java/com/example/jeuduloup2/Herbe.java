package com.example.jeuduloup2;

public class Herbe extends Vegetaux {
    public Herbe(int x, int y) {
        super(2, x, y);
    }
}
