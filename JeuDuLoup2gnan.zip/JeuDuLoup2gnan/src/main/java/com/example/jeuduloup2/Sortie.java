package com.example.jeuduloup2;

public class Sortie extends Elements {
    public Sortie(int x, int y) {
        super(x, y);
    }

    public boolean estSortie() {
        return true;
    }
}
