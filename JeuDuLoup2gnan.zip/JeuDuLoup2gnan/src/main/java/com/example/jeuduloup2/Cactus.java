package com.example.jeuduloup2;

public class Cactus extends Vegetaux{

    public Cactus(int x, int y) {
        super(1,x,y);
    }

}

