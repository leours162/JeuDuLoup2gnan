package com.example.jeuduloup2;

public class Rocher extends Elements {
    public Rocher(int x, int y) {
        super(x, y);
        this.rendreInaccessible();
    }
}
