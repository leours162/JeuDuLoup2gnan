package com.example.jeuduloup2;

public class Loup extends Animal {

    public Loup(int x, int y) {
        super(3, x, y);
    }
}
